# Stock Market Prediction Interface Documentation

## Overview

This project implements a complete stock price prediction system using ARIMA (AutoRegressive Integrated Moving Average) models with a Streamlit web interface. The system allows users to input stock symbols, select date ranges, and generate predictions for future stock prices.

## Architecture Overview

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Streamlit     │    │   Data Pipeline  │    │   ARIMA Model   │
│   Interface     │───▶│   (yfinance)     │───▶│   (statsmodels) │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   User Input    │    │   Data Cleaning  │    │   Forecasting   │
│   & Display     │    │   & Processing   │    │   & Visualization│
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Components Breakdown

### 1. Streamlit Interface (`streamlit_app.py`)

The main application file that provides the web interface for users to interact with the prediction system.

#### Key Features:
- **Sidebar Controls**: Stock symbol input, date range selection, forecast period slider
- **Real-time Processing**: Live data download and model training
- **Interactive Visualization**: Dynamic charts showing historical data and predictions
- **Error Handling**: Graceful handling of invalid inputs and data issues

#### Interface Flow:
```python
# User Input Section
stock_symbol = st.sidebar.text_input('Enter Stock Symbol (e.g., AAPL):', 'AAPL')
start_date = st.sidebar.date_input('Start Date:', pd.to_datetime('2018-01-01'))
end_date = st.sidebar.date_input('End Date:', pd.to_datetime('2024-12-31'))
forecast_steps = st.sidebar.slider('Forecast Days:', 1, 90, 30)
```

### 2. Data Pipeline

#### Data Acquisition (`download_data` function)
```python
def download_data(symbol, start, end):
    df = yf.download(symbol, start=start, end=end)
    return df
```

**Process:**
1. Uses `yfinance` library to fetch historical stock data
2. Downloads OHLCV (Open, High, Low, Close, Volume) data
3. Returns pandas DataFrame with datetime index

#### Data Processing
```python
close_series = df['Close'].copy() if 'Close' in df.columns else df[('Close', stock_symbol)].copy()
close_series = close_series.fillna(method='ffill')
```

**Steps:**
1. **Column Selection**: Handles both single-level and multi-level column indices
2. **Missing Value Handling**: Forward-fills any gaps in the data
3. **Data Validation**: Ensures sufficient data for ARIMA modeling

### 3. ARIMA Model Training

#### Auto ARIMA Model Selection
```python
model_auto = auto_arima(close_series,
                        start_p=1, start_q=1,
                        max_p=5, max_q=5,
                        seasonal=False,
                        d=1,
                        trace=False,
                        error_action='ignore',
                        suppress_warnings=True,
                        stepwise=True)
```

**Parameters Explained:**
- `start_p=1, start_q=1`: Starting values for AR and MA orders
- `max_p=5, max_q=5`: Maximum values for AR and MA orders
- `seasonal=False`: No seasonal component (daily stock data)
- `d=1`: First-order differencing for stationarity
- `stepwise=True`: Uses stepwise algorithm for efficiency

#### Model Fitting
```python
model = ARIMA(close_series, order=model_auto.order)
fitted_model = model.fit()
```

**Process:**
1. Creates ARIMA model with optimal parameters from auto_arima
2. Fits the model to historical data
3. Returns fitted model ready for forecasting

### 4. Prediction Process

#### Forecasting
```python
forecast = fitted_model.forecast(steps=forecast_steps)
forecast_index = pd.date_range(start=close_series.index[-1] + pd.Timedelta(days=1), 
                              periods=forecast_steps)
```

**Steps:**
1. **Generate Forecast**: Uses fitted ARIMA model to predict future values
2. **Create Date Index**: Generates future dates for forecast period
3. **Return Predictions**: Returns forecasted values with corresponding dates

#### Visualization
```python
fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(close_series, label='Historical')
ax.plot(forecast_index, forecast, label='Forecast', color='green')
ax.set_title(f"{stock_symbol} ARIMA Forecast (Next {forecast_steps} Days)")
ax.set_xlabel("Date")
ax.set_ylabel("Closing Price (USD)")
ax.legend()
ax.grid(True)
plt.tight_layout()
st.pyplot(fig)
```

## How the Model Works

### ARIMA Model Theory

ARIMA (AutoRegressive Integrated Moving Average) models are designed for time series forecasting and consist of three components:

1. **AR (AutoRegressive)**: Uses past values to predict future values
2. **I (Integrated)**: Differencing to make the series stationary
3. **MA (Moving Average)**: Uses past forecast errors to predict future values

### Model Selection Process

1. **Stationarity Check**: Data is differenced (d=1) to achieve stationarity
2. **Parameter Optimization**: Auto ARIMA tests different (p,d,q) combinations
3. **Model Selection**: Chooses the best model based on AIC/BIC criteria
4. **Model Fitting**: Fits the selected model to historical data

### Prediction Workflow

```
Historical Data → Data Cleaning → Stationarity → ARIMA Fitting → Forecasting
     ↓              ↓              ↓              ↓              ↓
   yfinance    →  fillna()   →  differencing →  model.fit() →  forecast()
```

## Dependencies

### Core Libraries
- **streamlit**: Web interface framework
- **yfinance**: Yahoo Finance data API
- **pandas**: Data manipulation and analysis
- **matplotlib**: Data visualization
- **statsmodels**: ARIMA model implementation
- **pmdarima**: Auto ARIMA for automatic model selection

### Installation
```bash
pip install -r requirements.txt
```

## Usage Instructions

### Running the Application
```bash
streamlit run streamlit_app.py
```

### Step-by-Step Usage
1. **Enter Stock Symbol**: Type a valid stock symbol (e.g., AAPL, MSFT, TSLA)
2. **Select Date Range**: Choose start and end dates for historical data
3. **Set Forecast Period**: Use slider to select number of days to predict
4. **Run Prediction**: Click "Run Prediction" button
5. **View Results**: Examine historical data, model parameters, and forecast

### Recommended Test Cases
- **AAPL** (2020-01-01 to 2024-12-31, 30 days forecast)
- **MSFT** (2019-01-01 to 2024-12-31, 45 days forecast)
- **TSLA** (2020-01-01 to 2024-12-31, 30 days forecast)

## Model Performance Considerations

### Strengths
- **Automatic Parameter Selection**: Auto ARIMA finds optimal model parameters
- **Handles Non-stationary Data**: Automatic differencing for stationarity
- **Real-time Processing**: No pre-trained models, adapts to current data
- **User-friendly Interface**: Intuitive Streamlit interface

### Limitations
- **Assumes Linear Relationships**: ARIMA models are linear
- **Requires Sufficient Data**: Needs adequate historical data for training
- **Market Volatility**: May not capture sudden market changes
- **No External Factors**: Doesn't consider news, events, or market sentiment

### Best Practices
1. **Use Longer Date Ranges**: More data generally improves model performance
2. **Avoid Very Short Forecasts**: 7-90 days work best
3. **Test Multiple Symbols**: Different stocks may require different approaches
4. **Monitor Model Parameters**: Check the optimal ARIMA order for insights

## Error Handling

### Common Issues and Solutions
1. **Invalid Stock Symbol**: Check symbol spelling and validity
2. **Insufficient Data**: Use longer date ranges
3. **Network Issues**: Retry data download
4. **Model Convergence**: Try different date ranges or symbols

### Data Validation
- Checks for empty DataFrames
- Validates date ranges
- Handles missing values
- Ensures sufficient data for modeling

## Future Enhancements

### Potential Improvements
1. **Multiple Models**: Add LSTM, Prophet, or ensemble methods
2. **Feature Engineering**: Include volume, technical indicators
3. **Model Persistence**: Save trained models for faster predictions
4. **Confidence Intervals**: Add prediction uncertainty bands
5. **Real-time Updates**: Live data streaming capabilities

## Technical Notes

### Data Sources
- **Primary**: Yahoo Finance API (yfinance)
- **Format**: OHLCV data with datetime index
- **Frequency**: Daily data

### Model Parameters
- **Default Differencing**: d=1 (first-order)
- **Parameter Range**: p,q ∈ [1,5]
- **Seasonality**: Disabled (daily data)
- **Optimization**: Stepwise algorithm with AIC/BIC

### Performance Metrics
- **Model Selection**: AIC (Akaike Information Criterion)
- **Forecast Accuracy**: Can be measured with RMSE, MAE
- **Model Diagnostics**: Residual analysis and Ljung-Box test

This documentation provides a comprehensive understanding of how the stock prediction interface works, from data acquisition to model training and prediction generation. 